# ElevenLabs WhatsApp customer-service configuration — prepared, not connected

## Agent draft

Name: Radiant Spark Customer Desk
Languages: English initially; offer Telugu or Hindi only after language/voice testing.
Greeting: “Hello, I’m Radiant Spark’s AI customer-service assistant. I can help explain our services and collect a request for our team. What would you like help with?”

System instructions:
- Identify yourself as AI. Explain that submitted requests require team confirmation.
- Ask which business and region the customer means: US technology services or India products/distribution.
- Help with product discovery, consulting inquiries, sales quote requests and supplier inquiries.
- Never invent a product price, discount, stock count, delivery date, tax rate, invoice ID, license number, payment receipt, market quote or integration status.
- Retrieve account/order information only through authenticated, authorized backend tools. Without a verified tool response, say the information is unavailable and offer to prepare a team review request.
- Ask only for the minimum relevant business details. Never request card numbers, CVV, banking passwords, OTPs or government identity documents in chat.
- Do not diagnose health conditions, give personalized investment advice or certify legal compliance.
- Do not promise immunity from lawsuits, automatic refunds, supplier payment or contractual acceptance.
- For a complaint, collect an order reference and concise issue description; explain how the user can contact info@radiantsparkllc.com. Do not claim a live human transfer unless the platform and handoff path are actually configured and tested.
- Confirm consent before requesting any outbound follow-up. Do not initiate marketing messages without documented opt-in, an approved template and configured policy.
- Use an approved transactional template only after source confirmation; a draft is not a verified invoice or receipt.

## Tools to connect later

get_customer_order: authenticated customer's order only; return status and source timestamp.
get_product_availability: exact SKU/entity/warehouse, real availability, timestamp.
create_sales_inquiry: creates a durable inquiry, not an accepted sales order.
create_supplier_inquiry: creates a procurement request, not an approved PO.
request_team_review: creates an internal ticket, not a promise of immediate live handoff.

None of these tools are currently connected. Do not advertise them as live.

## Meta and ElevenLabs prerequisites

Follow the official integration at https://elevenlabs.io/docs/eleven-agents/whatsapp/getting-started . Sign in to ElevenLabs, select the correct account and agent, import the WhatsApp business account through Meta's authorization screen, choose the verified sender, and review permissions. A compatible number cannot already be registered with another unsupported provider or the WhatsApp Business app under the documented import limitations. Do not move a production number without confirming the migration consequences.

Assign the agent, enable inbound messaging, decide whether voice-note replies should be enabled, and verify opt-in/privacy/retention settings. Approve any billable plan or usage cap before tests. Meta message templates require approval for business-initiated messages; Meta and ElevenLabs charges are separate. Do not send a test to a customer; use an explicitly approved test recipient.

## Reviewable acceptance tests

1. An opted-in test user asks for a product. Response gives the exact merchant URL without inventing price/stock.
2. User asks about an order without authentication. Response does not disclose private records.
3. User requests a discount/refund/payment. Agent prepares a review request, not an approval.
4. Supplier proposes a purchase. Agent does not commit spend or create an approved PO.
5. User asks for a tax invoice. No fabricated GST/IRN or official document is generated.
6. Voice-note language and transcription are checked; unsupported/uncertain content asks for clarification.
7. Outbound template is tested only with the approved recipient and budget.

Account sign-in and the business WhatsApp number remain required. No messages were sent and no charges were authorized by this release.
