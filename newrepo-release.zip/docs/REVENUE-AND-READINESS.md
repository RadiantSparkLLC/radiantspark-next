# Revenue and operational readiness

## Audit rating before this release

Subjective assessment, not an external award or performance certification: 5/10 overall. Visual identity is distinctive, but unsupported live inventory, official-invoice, ERP, agent and legal-immunity claims materially reduce trust. There is no verified traffic, sales conversion or revenue dataset to score commercial performance.

## What this release implements

- Original dark homepage layout and palette retained. A perspective-projected animated 3D globe with reduced-motion and offscreen pause support works without WebGL.
- No customer-facing ZIP control in SparkSync. Mock trading, cleaner, subscriptions, account balances and readiness scores removed from that app.
- Main market strip uses a provider-hosted TradingView widget instead of fixed prices. Stock quotes may be delayed; the provider documents real-time forex/crypto, subject to symbol availability. No exchange license was purchased and guaranteed real-time stock redistribution is NOT enabled. If the third-party widget is blocked, no fabricated values appear.
- SparkDeals shows five source-checked product-specific merchant links, search, region filtering and saved products. The user lands on the actual product page. No scraped price, invented discount or stock count is shown. These curated links are not a live price feed or confirmed affiliate relationships. Authorized data credentials are still required for automatically refreshed on-site prices and commission tracking.
- O2C and P2P are visible through the homepage and app. Blank customer and supplier forms prepare email drafts; no order is accepted, PO issued, invoice certified or payment collected by the form. Actual transactional workflows require an authenticated durable backend, verified product data, inventory source, payment and warehouse integrations.
- False agent-online/accuracy, official tax invoice, IRN, stock and ERP status panels replaced with clear role descriptions and source-connection status.
- Unqualified legal-immunity and blanket liability-cap statements replaced by clear responsibilities and preserved consumer rights. Terms and privacy explain actual features; local counsel must review contractual terms and regulatory obligations.
- No AdSense added, as requested.

## Connections still required

1. Commercial real-time market-data agreement allowing public website redistribution for the exchanges/symbols desired, plus securely stored credentials. A private trading subscription is not automatically a public redistribution license.
2. Approved affiliate/merchant publisher accounts and authorized product feeds, with permitted caching and images, product URLs, timestamps, offer expiry, disclosures and tracking IDs. Current product-page links alone do not establish commission eligibility.
3. Actual inventory/order source and warehouse/payment access. Server-enforced identity, idempotency, inventory transactions, approvals, reconciliation, audit records and webhook verification must precede a live O2C/P2P claim.
4. ElevenLabs account sign-in, existing agent or agent creation approval, Meta business portfolio, compatible WhatsApp business number, sender authorization, customer opt-in, approved message templates and a defined spending cap.
5. Paid advertising: confirm budget, geography, offer, conversion goal and account. Draft copy below has NOT been launched.

## Promotion drafts — not launched

Campaign A: Consulting leads
- Headline: Oracle Cloud & Integration
- Headline: Turn Process Gaps Into a Plan
- Headline: Talk to Radiant Spark
- Description: Discuss your Oracle, reporting or integration challenge. Request a scoped project conversation with our team.
- Landing page: partner.html?utm_source=google&utm_medium=cpc&utm_campaign=consulting_inquiries
- Goal: qualified inquiry and a reviewed proposal, not ad clicks alone.

Campaign B: Product discovery
- Headline: Find the Exact Product Page
- Headline: Explore US & India Products
- Description: Build a shortlist and open the merchant’s product page. Confirm price, seller and delivery before buying.
- Landing page: sparkdeals.html?utm_source=instagram&utm_medium=paid_social&utm_campaign=product_discovery
- Launch only after licensed feed coverage, affiliate eligibility and conversion tracking are established; otherwise paid traffic may generate no affiliate revenue.

Campaign C: Wholesale inquiries
- Headline: Discuss Wholesale Requirements
- Description: Share your product, quantity and delivery location. Our team will review availability and commercial terms.
- Landing page: operations.html?utm_source=google&utm_medium=cpc&utm_campaign=wholesale_inquiries#o2c
- Do not advertise confirmed stock, licenses or prices without evidence.

15-second consulting Reel draft:
“Spreadsheets, reports and systems don’t always agree. Start with the process. Radiant Spark helps businesses discuss Oracle, cloud and integration requirements. Tell us what is slowing your team down. Request a project conversation.”

15-second product discovery Reel draft:
“Looking for a specific product? Shortlist it on SparkDeals, choose your region and open its merchant page. Check the seller, final price and delivery before buying. Save your favorites for later.”

Disclose any paid partnership or affiliate relationship clearly. Use original or licensed footage/music. No auto-posting or customer messages have been sent.

## How creators in India earn

YouTube: eligible creators can share advertising/Premium revenue through YPP, and separately earn sponsorship, affiliate or product/service revenue. Standard ad-revenue eligibility includes 1,000 subscribers with 4,000 qualified watch hours in 12 months OR 10 million qualified Shorts views in 90 days, plus policy review and other requirements. AdSense for YouTube is part of YouTube’s payment setup; choosing no website AdSense does not remove that YouTube requirement. Verify current YouTube Studio Earn eligibility rather than promise earnings per view.

Instagram: brand partnerships, UGC work, affiliate conversions and selling products/services are practical channels. Creator marketplace availability and monetization features are account/country dependent; India marketplace expansion is documented by Meta. Gifts/subscriptions/bonuses must be checked in the actual Professional Dashboard; there is no universal guaranteed payment per Reel view.

## Sources and limitations

TradingView: https://www.tradingview.com/widget-docs/faq/data/ and https://www.tradingview.com/widget-docs/widgets/tickers/legacy-ticker-tape
YouTube: https://support.google.com/youtube/answer/72851
Meta creator partnerships: https://about.fb.com/news/2024/02/creator-marketplace-for-brands-and-creators-to-collaborate-on-instagram/
ElevenLabs: https://elevenlabs.io/docs/eleven-agents/whatsapp/getting-started
Consumer Protection Act (India): https://www.indiacode.nic.in/indiacode/handle/123456789/15256
FTC disclosures: https://www.ftc.gov/node/60343

Public web name searches do not constitute a complete lawsuit search or establish that a named company record is the user’s entity. Exact legal identifiers, jurisdictions, court access and legal review are needed for meaningful litigation due diligence. No no-lawsuit, regulatory approval, award or revenue guarantee is made.
