# Production integration roadmap

This release is a static GitHub Pages website and a working, deterministic operations simulation. It is NOT a production ERP, payment checkout, language-model chatbot or autonomous purchasing system. No credentials were supplied or embedded. Browser data resets on reload and is neither shared nor durable.

## Required architecture

Website -> authenticated backend -> durable order/inventory database -> permitted external services.
Composio belongs on the backend, where it can expose allowlisted tools to the AI runtime. Website users must never choose arbitrary tools, business identities, or connected accounts. An LLM may propose an action; server-side policy must authorize it and a transaction must enforce its invariants.

## Essential server operations

- GET /api/catalog: validated SKUs, price currency, sellable quantity and last source synchronization timestamp.
- POST /api/orders: authenticated customer, SKU, integer quantity and idempotency key. Recalculate prices on server. Reserve within a database transaction using a conditional update or lock. If insufficient, roll back and return conflict.
- POST /api/checkout: server creates a hosted checkout session for the saved order. Never accept the browser's subtotal as authoritative.
- POST /api/webhooks/payments: verify processor signature against original request bytes; deduplicate events. Confirm amount, currency, order identity and lifecycle. A redirect to success never proves payment.
- POST /api/warehouse/dispatch: staff/service authorization, payment or approved credit gate, reservation conversion to stock movement in one transaction. Duplicate events cannot deduct twice.
- POST /api/requisitions: approved supplier and replenishment proposal. Separate requester/approver where required. Receipt must record accepted quantity and batch. Invoice matching must compare actual PO, receipt and invoice, including tolerances. Payment is an independently authorized step.
- GET /api/market-quotes: provider license permitting public display, entitlement checks, provider timestamp, delayed/live flag, cache TTL. Show unavailable/stale states on feed failure. No brokerage functionality is included.

## Minimum data records

business_entities, users, customer_memberships, products, warehouses, inventory_balances, reservations (expiry and release status), inventory_movements, orders, order_lines, payment_events (unique provider event ID), shipments, suppliers, requisitions, purchase_orders, receipts, supplier_invoices, approvals, agent_runs, audit_events.

All business data must carry entity_id. Enforce record authorization on every request. Maintain separate US/India ledgers and currencies. Money should use integer minor units. Store API keys only in server secrets. Redact logs, apply rate limits, verify inbound webhooks and use retry queues/dead-letter handling. Releases, cancellations, refunds, partial receipts, expired stock and reconciliation need production tests.

## Ten role permissions

Maya: route/inspect workflow. Arjun: validate/draft orders within approved price rules. Sarah: read only the authenticated customer's records. Rajesh: read inventory and propose production. Priya: propose replenishment; cannot approve or pay. Elena: invoice/payment reconciliation; cannot mark payment without source evidence. Vikram: request dispatch only after gates. Marcus: integration diagnostics with redacted logs. Ananya: flag policy issues for qualified review; cannot certify legal compliance. David: aggregated forecasting; no access to card credentials.

Use a durable workflow runner for jobs; Composio is the tool-connection layer, not the inventory ledger or physical stock sensor. Check current Composio documentation before implementation: https://docs.composio.dev/docs/authentication and https://docs.composio.dev/docs/toolkits . Custom connectors may be necessary for Oracle or internal systems; support has not been verified in this package.

## Go-live dependencies

Confirm the actual order/inventory source, hosting/backend account, production payment account and products, warehouse/carrier integration, Composio account, permitted toolkit scopes, AI provider, reviewed tax/pricing rules and market-data permissions. Then implement and sandbox-test the server integrations before changing the demo labels.
