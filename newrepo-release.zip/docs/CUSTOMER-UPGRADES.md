# SparkDeals and SparkSync release

The original homepage, background, navigation and globe files are unchanged. Only SparkDeals, SparkSync and new supporting files are updated. No live deployment was performed.

## Audit findings

The uploaded SparkDeals page contained a hardcoded dealsData array with prices, votes and a fixed live shopper count; no merchant fetch, stock check or daily publication job existed. SparkSync generated random heart rates and displayed fixed activity/sleep/readiness values; no Bluetooth, Apple Health, Google Health Connect or Bevel API existed. The public page URLs could not be fetched by the research service, so these are source findings, not proof that every current deployed byte matches this archive.

## Delivered

SparkDeals preserves its navy layout and stores, adds newest/discount sorting, checked-today and device-local saved filters, manual refresh, visible source publication times, five-minute visible-page refresh, and hiding of offers older than 24 hours or expired. Store directories show no invented price, votes or shoppers. No offers are claimed when the feed is empty or unavailable. Health metrics do not influence deals. Saved offer IDs are stored only in browser localStorage.

SparkSync includes a user-triggered Web Bluetooth chooser for the standard Heart Rate service, 8/16-bit heart-rate packet parsing, notification streaming, disconnect/clear, 30-second stale-reading clearing and unsupported-browser guidance. Raw sensor readings remain in memory; no health upload or persistent storage is added. Sample ECG and randomized heart-rate claims were removed. Apple Health/Watch, Google Health Connect and Bevel are explicitly disconnected. Legacy unrelated app cards are labeled demonstrations. Physical sensor pairing was not possible in this environment.

## Daily offers: connection required

A scheduled GitHub Actions workflow runs at 09:00 UTC daily (GitHub may delay scheduled execution) or manually. It reads an authorized provider feed from the repository secret DEALS_FEED_URL, with optional DEALS_FEED_TOKEN, validates it and updates deals-feed.json. With no source configured, it does nothing. No merchant account, affiliate approval or source feed was available here. Daily fresh offers are therefore NOT active in this delivery. Arbitrary retailer HTML and generic store links are not converted into verified prices. Merchant feeds must be licensed/authorized and normalized to this schema.

Example feed schema (illustrative, NOT an actual offer):

```json
{
  "updatedAt": "2026-11-08T09:00:00Z",
  "deals": [{
    "id": "merchant-product-offer-id",
    "title": "Merchant supplied product title",
    "merchant": "Amazon US",
    "category": "amazon_us",
    "description": "Merchant supplied terms",
    "price": 25,
    "currency": "USD",
    "discountPercent": 10,
    "url": "https://www.amazon.com/dp/REPLACE_WITH_REAL_PRODUCT",
    "checkedAt": "2026-11-08T09:00:00Z",
    "expiresAt": "2026-11-08T21:00:00Z"
  }]
}
```

URLs must use HTTPS on an allowed existing retailer domain; credentials in URLs are rejected. IDs must be unique. Price must be nonnegative; currency USD or INR. checkedAt must be within 24 hours; offer must be unexpired. Source timestamps are never replaced with the download time. The default empty feed uses updatedAt:null. Existing prices are not verified by refreshing the browser; only the feed publisher can validate merchant facts. Verify currency and product eligibility with the source. Add new merchants explicitly in deal-utils.js only after review.

Important for GitHub Pages: commits made using the Actions GITHUB_TOKEN do not trigger another Pages build. For daily changes to reach the public site, configure your repository's Pages deployment to run on workflow_run completion, or incorporate this refresh job into your existing Pages deployment workflow. The supplied sync job updates source only; it is not a verified deployment workflow. Secret configuration, repository settings and authorized data supply remain pending.

## Health integrations

- BLE: HTTPS, user action and a compatible browser/device exposing the standard Heart Rate GATT service. Generic Bluetooth pairing does not expose a watch's entire health database. No ECG, diagnosis, sleep or readiness inference is implemented.
- Apple Health: native iOS app, HealthKit entitlement and granular user authorization. A PWA alone does not implement this.
- Google Health Connect: native Android SDK and data-type permission flow. A website alone does not implement this.
- Bevel: Bevel's own documentation lists supported connections, but no direct public SparkSync-to-Bevel integration was verified. Do not advertise it as connected.

Official references: https://developer.chrome.com/docs/capabilities/bluetooth ; https://developer.apple.com/documentation/healthkit/authorizing-access-to-health-data ; https://developer.android.com/health-and-fitness/health-connect/get-started ; https://help.bevel.health/en/articles/10400449 .

## Verification

Run `node --test tests/*.cjs`. 11 tests passed, including original order/P2P logic, valid/stale/expired/unsafe feed entries, duplicate offer IDs, missing publication times and 8/16-bit/truncated sensor packets. Browser checks confirmed directory fallback, saved-only empty state, unsupported Bluetooth feedback and expandable platform guidance. In an isolated TEST OFFER fixture, a dated offer loaded, Save toggled successfully and the saved-only filter retained it; the test save was then removed. The fixture is excluded from the release. No live merchant, affiliate payout or physical sensor integration was verified. Awards and customer revenue are not guaranteed.
