# Validation report

Automated: `node --test tests/workflows.test.cjs` — 6 passed, 0 failed.

1. Reservations reduce sellable availability without prematurely reducing on-hand; overselling rejected.
2. Repeated request with same idempotency key reserves only once.
3. Zero, negative, fractional, NaN and infinite quantities rejected without mutation.
4. Shipment blocked until simulated payment; repeated confirmation/dispatch cannot deduct twice.
5. Purchase approval does not increase stock; goods receipt increases once; matching precedes simulated approved payment.
6. All ten agent roles have unique identities and responsibility text.

Browser: created a 20-case order, observed availability change from 420 to 400 and pending-payment status, simulated payment confirmation and dispatch, observed on-hand 460/reserved 40/blocked 20. Ran isolated ten-role demonstration and observed all ten distinct outputs. Created purchase request and advanced approval to awaiting receipt. Fixed randomUUID compatibility on non-secure local previews. JavaScript syntax checks passed.

Limitations: tests validate simulation logic, not AI quality or live integrations. No actual ERP, market-feed, tax, checkout, carrier or supplier credentials were present. No real transactions were executed. Production multi-user concurrency and authentication remain unimplemented. Mobile homepage inspected in a 390px embedded viewport; no horizontal page overflow observed. Mobile CSS includes responsive grids, scrollable data tables, fluid type and accessible focus; device-specific hardware testing was not performed.
