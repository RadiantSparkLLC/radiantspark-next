# Radiant Spark Next

Separate public preview website. The existing radiantspark-site repository and radiantsparkllc.com are unchanged.

Pages entry: index.html; SparkDeals: sparkdeals.html; SparkSync: app.html; workflow demonstration: operations.html.

Daily merchant offers need an authorized feed; none is configured. Bluetooth supports standard BLE heart-rate sensors on compatible HTTPS browsers; hardware pairing is unverified. Apple Health, Health Connect and Bevel are not connected. Read docs/CUSTOMER-UPGRADES.md.

No custom domain is attached. Paths target /radiantspark-next/.
