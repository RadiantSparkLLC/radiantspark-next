// Product-specific merchant pages checked against public sources on 2026-11-08.
// These are discovery links, not live offers or confirmed affiliate relationships.
window.SparkProductPages=[
{id:'apple-us-airpods-pro3',title:'AirPods Pro 3',merchant:'Apple US',category:'apple_us audio tech',region:'US',url:'https://www.apple.com/shop/buy-airpods/airpods-pro-3',emoji:'🎧',checkedAt:'2026-11-08',description:'Open the exact product page to choose options and see the current merchant price.'},
{id:'apple-in-airpods-pro3',title:'AirPods Pro 3 · India',merchant:'Apple India',category:'apple_in audio tech',region:'IN',url:'https://www.apple.com/in/shop/buy-airpods/airpods-pro-3',emoji:'🎧',checkedAt:'2026-11-08',description:'India product page. Confirm local availability, delivery and any eligibility conditions with Apple.'},
{id:'apple-us-iphone17',title:'iPhone 17',merchant:'Apple US',category:'apple_us phones tech',region:'US',url:'https://www.apple.com/shop/buy-iphone/iphone-17',emoji:'📱',checkedAt:'2026-11-08',description:'Choose storage, color and carrier options on the merchant’s product page.'},
{id:'apple-in-iphone17',title:'iPhone 17 · India',merchant:'Apple India',category:'apple_in phones tech',region:'IN',url:'https://www.apple.com/in/shop/buy-iphone/iphone-17',emoji:'📱',checkedAt:'2026-11-08',description:'Open the India product page for current pricing, configuration and delivery.'},
{id:'bestbuy-airpods-pro3',title:'AirPods Pro 3 · Best Buy',merchant:'Best Buy',category:'bestbuy audio tech',region:'US',url:'https://www.bestbuy.com/product/apple-airpods-pro-3/6376563',emoji:'🎧',checkedAt:'2026-11-08',description:'Specific product listing. Confirm new/open-box selection, seller and availability at the retailer.'}
];
