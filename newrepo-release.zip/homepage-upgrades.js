// Preserve the existing visual design while routing customers to the updated apps.
(function(){
 const base='/radiantspark-next/';
 document.addEventListener('click',function(e){const b=e.target.closest('button');if(!b)return;if(/sparkdeals/i.test(b.textContent)){e.preventDefault();e.stopImmediatePropagation();location.href=base+'sparkdeals.html';}},true);
 const replacements=[
 ['LIVE MARKETS','MARKET PREVIEW · SAMPLE DATA'],
 ['Features Dynamic Island status bar, 3D rotating Biometric Plexus (75 bpm cardiac pulse), Apple Watch Health Telemetry, Smart Photo Cleaner (7.1 MB recoverable), Market Pulse (SPY, QQQ), and 8-tab native navigation.','SparkSync offers a compatible Bluetooth heart-rate sensor connection flow and eight-tab navigation. Apple Health, Google Health Connect and Bevel are not connected. Other legacy app cards are demonstrations.'],
 ['Real-time deals aggregator for Amazon US, Amazon India, Walmart, SHEIN, and direct merchant portals. Backed by Section 79 IT Act safe-harbor legal protections.','Explore retailer storefronts and dated published offers. Daily price updates require an authorized merchant feed, which is not connected yet.']
 ];
 function update(){const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const edits=[];while(walker.nextNode()){const n=walker.currentNode;if(n.parentElement?.closest('script,style,textarea'))continue;let t=n.nodeValue;for(const [from,to] of replacements)t=t.split(from).join(to);if(t!==n.nodeValue)edits.push([n,t])}for(const [n,t] of edits)n.nodeValue=t;}
 update();new MutationObserver(update).observe(document.body,{childList:true,subtree:true});
})();
